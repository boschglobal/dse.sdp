function model_create()
    print("Hello from Lua model")
end

function model_step()
end

function model_destroy()
end